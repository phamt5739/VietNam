function Car(name) {
    this.name = name;
}