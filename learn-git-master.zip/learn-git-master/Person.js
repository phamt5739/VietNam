function Person() {
    this.name = name;
    this.age = age;
}