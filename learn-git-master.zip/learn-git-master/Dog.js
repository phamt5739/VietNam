function Dog() {
  this.nameDog = nameDog;
}