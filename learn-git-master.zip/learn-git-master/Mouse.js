function Mouse(name) {
    this.name = name;
}

module.exports = Mouse;