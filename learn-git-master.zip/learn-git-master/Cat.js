function Cat() {

}

module.exports = Cat;